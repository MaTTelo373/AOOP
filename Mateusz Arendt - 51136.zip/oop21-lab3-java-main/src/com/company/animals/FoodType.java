package com.company.animals;

public enum FoodType {

    meat(0.70),
    crops(0.30),
    all(0.50);

    private final double foodToBodyRatio;

    FoodType(double foodToBodyRatio) {
        this.foodToBodyRatio = foodToBodyRatio;
    }

    public double getFoodToBodyRatio() {
        return foodToBodyRatio;
    }
}
