package com.company.animals;

public interface Feedable {
    void feed();
    void feed(FoodType foodType, Double foodWeight);
}
