package com.company.devices;

import com.company.animals.Human;

public class Car extends Device {

    private class Engine {
        private Double horsePower;
        private Double volume;
        private Double millage;

        private Boolean working;

        public Engine(Double horsePower, Double volume, Double millage) {
            this.horsePower = horsePower;
            this.volume = volume;
            this.millage = millage;
            this.working = false;
        }

        public Boolean getWorking() {
            return working;
        }

        public void setWorking(Boolean working) {
            this.working = working;
        }

        public void turnOn() {
            System.out.println("Hello We are going to Paradise ...");
            this.working = true;
        }

        public void turnOff() {
            System.out.println("Oh We are still alive ...");
            this.working = false;
        }

    }

    public Engine engine;

    public Double engineSize;
    public String fuelType;
    final static Double MAX_FUEL = 1.0;
    public Double currentFuel = 0.0;



    public Car(Double horsePower, Double volume, Double millage) {
        this.engine = new Engine(horsePower, volume, millage);
    }

    public Boolean isRunning() {
        return engine.getWorking();
    }

    public void startACar() {
        engine.turnOn();
    }

    public void stopACar() {
        engine.turnOff();
    }

    @Override
    public void turnOn() {
        System.out.println("Car is turned on");
    }

    @Override
    public void sell(Human seller, Human buyer, Double price) throws Exception {
        if(seller.getCar() == this) {
            if (buyer.cash >= price) {
                buyer.cash -= price;
                seller.cash += price;
                buyer.setCar(this);
                seller.setCar(null);
                System.out.println("Car has been sold");
            } else {
                throw new Exception("Buyer does not have enough money");
            }
        } else {
            throw new Exception("Seller does not own the car");
        }
    }

    public void refuel() {
        currentFuel = MAX_FUEL;
    }
}
