package com.company;

import com.company.animals.*;
import com.company.db.*;
import com.company.devices.*;
import com.company.runnable.*;

import java.math.BigDecimal;
import java.util.*;
import java.util.Map.*;
import java.util.concurrent.*;
import java.util.stream.Collectors;

import static com.company.devices.Phone.OperatingSystem.*;

import static com.company.Country.*;

public class Main {

    public static void main(String[] args) {

        Human me = new Human(1000.0);
        me.firstName = "Jan";
        me.lastName = "Kowalski";

        Animal dog = new Animal("dog");
        dog.name = "Szarik";
        Animal cat = new Animal("cat");
        cat.name = "Puszek";

        me.addPet(dog);
        me.addPet(cat);
        List<Animal> pets = me.getPets();
        for (Animal pet: pets) {
            System.out.println(pet.name);
        }

        for(int i=0;i<pets.size();i++) {
            System.out.println(String.format("Pet number %d is named %s and weights %.2f", i, pets.get(i).name, pets.get(i).getWeight()));
        }

        List<Animal> sortedAnimalsFirstApproach = pets.stream().sorted(Comparator.comparing(Animal::getWeight)).toList();
        for (Animal pet: sortedAnimalsFirstApproach) {
            System.out.println(String.format("Pet named %s weights %.2f", pet.name, pet.getWeight()));
        }
        List<Animal> sortedAnimalsSecondApproach = pets.stream().sorted(new AnimalWeightComparator()).toList();
        for (Animal pet: sortedAnimalsSecondApproach) {
            System.out.println(String.format("Pet named %s weights %.2f", pet.name, pet.getWeight()));
        }

        me.fingerNames[0] = "Left pinkie";
        me.fingerNames[1] = "Left ring";
        me.fingerNames[2] = "Left middle";
        me.fingerNames[3] = "Left index";
        me.fingerNames[4] = "Left thumb";

        me.fingerNames[5] = "Right thumb";
        me.fingerNames[6] = "Right index";
        me.fingerNames[7] = "Right middle";
        me.fingerNames[8] = "Right ring";
        me.fingerNames[9] = "Right pinkie";

        System.out.println(String.format("I have %d fingers", me.fingerNames.length));

        for (String fingerName: me.fingerNames) {
            System.out.println(fingerName);
        }

        List<String> sortedFingerNames = Arrays.stream(me.fingerNames).sorted().toList();

        for (String fingerName: sortedFingerNames) {
            System.out.println(fingerName);
        }




        Phone onePlus = new Phone("onePlus",
                "8Pro",
                2.3,
                Android);

        Phone iPhone6 = new Phone("Apple", "6s", 5.0, iOS);

        System.out.println("phone: " + onePlus);
        System.out.println("phone: " + iPhone6);
        System.out.println("human: " + me);


        onePlus.turnOn();

        Car fiat = new Car(60d, 1d, 120000d);
        fiat.engineSize = 1.9;
        fiat.fuelType = "Diesel";
        fiat.setProducer("Fiat");
        fiat.setModel("Bravo");

        System.out.println(iPhone6.getModel());
        System.out.println(iPhone6.getProducer());
        System.out.println(iPhone6.os);
        System.out.println(iPhone6.screenSize);


        fiat.turnOn();
        iPhone6.turnOn();


        BigDecimal d = BigDecimal.valueOf(10, -2);
        System.out.println(d.doubleValue());

        task4();
        task5();
        task6();


        task10();
        task11();
        task12_13_14();
        task15();
        task16();
        task17();

        task9A();
        task9B();
        task9C();
        task9D();
        task9E();
    }


    public static  <K, V extends Comparable<V>> K maxOnMap(Map<K, V> map) {
        Optional<Entry<K, V>> maxEntry = map.entrySet()
                .stream()
                .max((Entry<K, V> e1, Entry<K, V> e2) -> e1.getValue()
                        .compareTo(e2.getValue())
                );

        return maxEntry.get().getKey();
    }

    public static  <K, V extends Comparable<V>> K minOnMap(Map<K, V> map) {
        Optional<Entry<K, V>> maxEntry = map.entrySet()
                .stream()
                .min((Entry<K, V> e1, Entry<K, V> e2) -> e1.getValue()
                        .compareTo(e2.getValue())
                );

        return maxEntry.get().getKey();
    }

    public static void task4() {
        System.out.println("----- Task4 -----");
        Map<Country, Double> countriesMap = new HashMap<Country, Double>() {
            {
                put(UKRAINE, 57000d);
                put(ITALY, 47000d);
                put(POLAND, 47000d);
                put(VATICAN, 0.01d);
                put(FRANCE, 67000d);
            }
        };
        System.out.println("The biggest : "+ maxOnMap(countriesMap));
        System.out.println("The smallest one : "+ minOnMap(countriesMap));
    }


    public static void task5() {
        System.out.println("----- Task5 -----");
        Map<String, Country> countriesMap = new HashMap<String, Country>() {
            {
                put("Kiev", UKRAINE);
                put("Roma", ITALY);
                put("Warsaw", POLAND);
                put("Roma", VATICAN);
                put("Paris", FRANCE);
            }
        };

        countriesMap.entrySet().stream()
                .sorted(Map.Entry.comparingByKey())
                .map(e -> String.format("%s ==>> %s", e.getKey(), e.getValue().toString()))
                .forEachOrdered(System.out::println);
    }

        public static void task6() {
            System.out.println("----- Task6 -----");
            Map<FoodType, List<Animal>> animalsMap = new HashMap<FoodType, List<Animal>>() {
                    {
                        put(FoodType.all, Arrays.asList(
                                new Human(1000d),
                                new Animal("dog")
                        ));
                        put(FoodType.meat, Arrays.asList(
                                new Human(10000d),
                                new Animal("cat")
                        ));
                        put(FoodType.crops, Arrays.asList(
                                new Human(100d),
                                new Animal("elephant")
                        ));

                    }
                };
            for (Map.Entry<FoodType, List<Animal>> entry : animalsMap.entrySet()) {
                 System.out.println(entry.getKey() + " : ");
                 for(Animal a : entry.getValue()) {
                     System.out.println(a.toString());
                 }

             }

        }

    public static void task8() {
        System.out.println("----- Task8 -----");
        List<Animal> animalsList =  Arrays.asList(
                new Human(1000d),
                new Animal("dog"),
                new Human(10000d),
                new Animal("cat"),
                new Human(100d),
                new Animal("elephant"));

        Collections.sort(animalsList, new Comparator<Animal>() {
            @Override
            public int compare(Animal o1, Animal o2) {
                return o1.getWeight().compareTo(o2.getWeight());
            }
        });


    }


    public static void task9A() {
        System.out.println("----- Task9A -----");
        Runner r1 = new Runner("Kajko");
        Runner r2 = new Runner("Kokosz");
        (new Thread(r1)).start();
        (new Thread(r2)).start();
    }

    public static void task9B() {
        System.out.println("----- Task9B -----");
        Runner r1 = new Fighter("SubZero");
        Runner r2 = new Fighter("Scorpion");
        (new Thread(r1)).start();
        (new Thread(r2)).start();
    }

    public static void task9C() {
        System.out.println("----- Task9C -----");
        Runner r1 = new Runner("SubZero 2", new Finisher() {
            @Override
            public void finishHim() {
                System.out.println("SubZero 2: is killing you ...");
            }
        });
        Runner r2 = new Runner("Scorpion 2", new Finisher() {
            @Override
            public void finishHim() {
                System.out.println("Scorpion 2: I never liked you buster ...");
            }
        });
        (new Thread(r1)).start();
        (new Thread(r2)).start();
    }

    public static void task9D() {
        System.out.println("----- Task9D -----");
        Runner r1 = new Runner("SubZero 3",  () -> {
             System.out.println("SubZero 3: is killing you ...");
         }
        );
        Runner r2 = new Runner("Scorpion 3",  () -> {
                System.out.println("Scorpion 3: I never liked you buster ...");
        });
        (new Thread(r1)).start();
        (new Thread(r2)).start();
    }

    public static void task9F() {
        System.out.println("----- Task9F -----");
        ExecutorService executorService = Executors.newFixedThreadPool(10);

        Future future1 = executorService.submit(
                new MyCallable(
                () -> {
                    System.out.println("First callable ....");
                }
                ));
        Future future2 = executorService.submit(new MyCallable(
                        () -> {
                            System.out.println("Second callable ....");
                        }
                ));
        Future future3 = executorService.submit(
                new MyCallable(
                        () -> {
                            System.out.println("Unknown callable ....");
                        }
                ));

        try {
            System.out.println("future.get() 1 = " + future1.get());
            System.out.println("future.get() 2 = " + future2.get());
            System.out.println("future.get() 3 = " + future3.get());
        } catch (ExecutionException | InterruptedException e) {
            System.err.println(e.getMessage());
        }

    }

    public static void task9E() {
        System.out.println("----- Task9E -----");
        ExecutorService executorService = Executors.newFixedThreadPool(10);

        Future future = executorService.submit(new MyCallable());

        try {
            System.out.println("future.get() = " + future.get());
        } catch (ExecutionException | InterruptedException e) {
            System.err.println(e.getMessage());
        }

    }

    public static void task10() {
        System.out.println("----- Task10 -----");
        Random r = new Random();
        List<Integer> list1n = new ArrayList<Integer>();
        List<Integer> list1f = new ArrayList<Integer>();
        for (int i = 0; i < (2005 + r.nextInt(2500)); i++) {
            Integer next = r.nextInt();
            list1n.add(next);
            list1f.add(next);
        }
        List<Integer> list2n = new ArrayList<Integer>();
        List<Integer> list2f = new ArrayList<Integer>();
        for (int i = 0; i < (2005 + r.nextInt(2500)); i++) {
            Integer next = r.nextInt();
            list2n.add(next);
            list2f.add(next);
        }
        List<Integer> list3n = new ArrayList<Integer>();
        List<Integer> list3f = new ArrayList<Integer>();
        for (int i = 0; i < (5 + r.nextInt(50)); i++) {
            Integer next = r.nextInt();
            list3n.add(next);
            list3f.add(next);
        }
        Long start = System.currentTimeMillis();
        System.out.println("----- Sort normal start -----");
        Collections.sort(list1n);
        Collections.sort(list2n);
        Collections.sort(list3n);
        System.out.println("----- Sort normal end ----: " + (double)(System.currentTimeMillis() - start)/1000) ;
        ExecutorService executorService = Executors.newFixedThreadPool(10);

        start = System.currentTimeMillis();
        System.out.println("----- Sort feature start -----");

        Future future1 = executorService.submit(
                new CallableSorter(list1f));
        Future future2 = executorService.submit(
                new CallableSorter(list2f));
        Future future3 = executorService.submit(
                new CallableSorter(list3f));
        try {
            System.out.println("----- Sort feature end ----: " + (double)(System.currentTimeMillis() - start)/1000 + " "
                           + future1.get().toString() +  future2.get().toString() +  future3.get().toString());
        } catch (ExecutionException | InterruptedException e) {
            System.err.println(e.getMessage());
        }

    }

    public static void task11() {
        System.out.println("----- Task8 -----");
        List<Animal> animalsList =  Arrays.asList(
                new Human(1000d),
                new Animal("dog"),
                new Human(10000d),
                new Animal("cat"),
                new Human(100d),
                new Animal("elephant"));

        List<Animal> sortedList = animalsList.stream()
                .sorted(Comparator.comparing(f -> f.getWeight()))
                .collect(Collectors.toList());


    }

    public static void task12_13_14() {
        System.out.println("----- Task12_13_14 -----");
        var c = new StorableCar("KIA", "Ceed", 2013, 25000d);
        try {
            System.out.println(ObjectToSql.insert(c));
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public static void task15() {
        System.out.println("----- Task15 -----");
        SuperNumber<Integer> i = new SuperNumber<>(123);
        i.print();
        System.out.println("int val:" + i.getInt());
        System.out.println("double val:" + i.getDouble());
        System.out.println("check eqIntAndDouble " + i.eqIntAndDouble());
        SuperNumber<Double> d = new SuperNumber<>(123d);
        d.print();
        System.out.println("int val:" + d.getInt());
        System.out.println("double val:" + d.getDouble());
        System.out.println("check eqIntAndDouble " + d.eqIntAndDouble());
        System.out.println("check d == i " + d.equals(i));

        SuperNumber<Double> dd = new SuperNumber<>(123.1d);
        SuperNumber<Integer> ii = new SuperNumber<>(123);
        System.out.println("check dd == ii " + dd.equals(ii));
        System.out.println("check ii == dd " + ii.equals(dd));

    }

    public static void task16() {
        System.out.println("----- Task16 -----");
        MyContainer<String> mc = new MyContainer<>(10);
        mc.add("Ala");
        mc.add("Krysia");
        mc.add("Zuzia");
        mc.add("Julia");

        mc.remove("Zuzia");

        Iterator i = mc.iterator();
        while (i.hasNext()) {
            System.out.println("imie: " + i.next());
        }

        System.out.println("changes: " + mc.getChanges());
     }

    public static void task17() {
        System.out.println("----- Task17 -----");
        MyContainerWithMemory<String> mc = new MyContainerWithMemory<>(10);
        mc.add("Ala");
        mc.add("Krysia");
        mc.add("Zuzia");
        mc.add("Julia");

        mc.remove("Zuzia");

        mc.printAll("name: ");
        mc.restoreToVersion(4);
        mc.print("name: ");
    }
}


