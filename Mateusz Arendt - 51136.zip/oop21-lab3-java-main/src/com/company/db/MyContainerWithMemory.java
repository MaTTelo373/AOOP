package com.company.db;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class MyContainerWithMemory<T> extends MyContainer<T>{ //task17

    private List<MyContainer<T>> history;


    public MyContainerWithMemory(int limit) {
        this.history = new ArrayList<MyContainer<T>>();
        this.history.add(new MyContainer<>(limit));
    }

    @Override
    public boolean add(Object o) {
       MyContainer<T> col = history.get(history.size() - 1);
       MyContainer<T> newCol = col.clone();
       boolean result =  newCol.add(o);
       if (result) {
           history.add(newCol);
       }
       return result;
    }

    @Override
    public boolean remove(Object o) {
        MyContainer<T> col = history.get(history.size() - 1);
        MyContainer<T> newCol = col.clone();
        boolean result =  newCol.remove(o);
        if (result) {
            history.add(newCol);
        }
        return result;
    }

    @Override
    public boolean addAll(Collection c) {
        MyContainer<T> col = history.get(history.size() - 1);
        MyContainer<T> newCol = col.clone();
        boolean result =  newCol.addAll(c);
        if (result) {
            history.add(newCol);
        }
        return result;
    }

    public void print(String prefix, int version) {
        if (version < history.size()) {
            System.out.println("version " + version);
            history.get(version).print(prefix);
        } else {
            System.out.println("no such version " + version);
        }
    }

    public void printAll(String prefix) {
        int version = 0;
        for(MyContainer<T> c : history) {
            print(prefix, version++);
        }
    }

    public boolean restoreToVersion(int version) {
        if (version < history.size()) {
            history.add(history.get(version));
            return true;
        }
        return false;
    }

    @Override
    public void print(String prefix) {
        history.get(history.size() - 1).print(prefix);
    }
}
