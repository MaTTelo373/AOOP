package com.company.db;

import java.util.Collection;
import java.util.Iterator;

public class MyContainer<T> implements Collection { //task16

    private int size;

    private T[] values;

    private int changes;

    public MyContainer(int limit) {
        this.values = (T[]) new Object[limit];
        this.size = 0;
        this.changes = 0;
    }

    public MyContainer() {
    }

    @Override
    public MyContainer<T> clone() {
        MyContainer<T> newCol = new MyContainer<T>(this.values.length);
        System.arraycopy(this.values, 0, newCol.values, 0, this.values.length);
        newCol.size = this.size;
        return newCol;
    }

    @Override
    public int size() {
        return size;
    }

    @Override
    public boolean isEmpty() {
        return size == 0;
    }

    @Override
    public boolean contains(Object o) {
        if (o == null) {
            return false;
        }
        for(T t : values) {
            if (t.equals(o)) {
                return true;
            }
        }
        return false;
    }

    @Override
    public Iterator iterator() {
        Iterator<T> iterator = new Iterator<T>()
        {
            private int i = 0;

            @Override
            public boolean hasNext() {
                return MyContainer.this.size > i;
            }

            @Override
            public T next() {
                return MyContainer.this.values[i++];
            }
        };
        return iterator;
    }

    @Override
    public Object[] toArray() {
        return this.values;
    }

    @Override
    public boolean add(Object o) {
        if (size < values.length) {
            values[size++] = (T)o;
            this.changes++;
            return true;
        }
        return false;
    }

    @Override
    public boolean remove(Object o) {
          for(int i=0; i<size; i++) {
              if (values[i].equals(o)) {
                  for(int j=i; j<size; j++) {
                      values[j] = values[j+1];
                  }
                  size--;
                  this.changes++;
                  return true;
              }
          }

         return false;
    }

    @Override
    public boolean addAll(Collection c) {
        Iterator<T> iter = (Iterator<T>)c.iterator();
        while (iter.hasNext()) {
            add(iter.next());
        }
        return c.size() > 0;
    }

    public int getChanges() {
        return changes;
    }

    @Override
    public void clear() {
        this.values =(T[]) new Object[this.values.length];
        this.size = 0;
        this.changes++;
    }

    @Override
    public boolean retainAll(Collection c) {
        return false;
    }

    @Override
    public boolean removeAll(Collection c) {
        return false;
    }

    @Override
    public boolean containsAll(Collection c) {
        return false;
    }

    @Override
    public Object[] toArray(Object[] a) {
        return new Object[0];
    }

    public void print(String prefix) {
        Iterator i = iterator();
        while (i.hasNext()) {
            System.out.println(prefix + i.next());
        }
        System.out.println("changes: " + getChanges());
    }
}
