package com.company.db;

@MappedClass
public class StorableCar {

    @Mapped
    private String producer;
    @Mapped
    private String model;
    @Mapped
    private Integer yearOfProduction;
    @Mapped
    private Double value;

    public StorableCar(String producer, String model, Integer yearOfProduction, Double value) {
        this.producer = producer;
        this.model = model;
        this.yearOfProduction = yearOfProduction;
        this.value = value;
    }

    public String getProducer() {
        return producer;
    }

    public String getModel() {
        return model;
    }

    public Integer getYearOfProduction() {
        return yearOfProduction;
    }

    public Double getValue() {
        return value;
    }
}
