package com.company.db;

public class SuperNumber<T extends Number> { //task15

    private T value;

    public SuperNumber(T value) {
        this.value = value;
    }

    public T getValue() {
        return value;
    }

    public double getDouble() {
        return value.doubleValue();
    }

    public double getInt() {
        return value.intValue();
    }

    public boolean eqIntAndDouble() {
        return getDouble() == getInt();
    }

   public void print() {
        System.out.println("Number type:" + value.getClass().getName());
        System.out.println("Number value:" + getValue());
   }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        SuperNumber<?> that = (SuperNumber<?>) o;

        return value != null ? value.equals(that.value) : that.value == null;
    }


}
