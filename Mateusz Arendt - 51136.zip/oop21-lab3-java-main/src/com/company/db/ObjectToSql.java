package com.company.db;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.beanutils.BeanMap;
import org.apache.commons.lang3.reflect.FieldUtils;

public class ObjectToSql { //task12

    public static String insert(Object pojo) throws Exception {
        if (!pojo.getClass().isAnnotationPresent(MappedClass.class)) {
            throw new Exception("Object is not mappable!");
        }

        Map<Object, Object> map = new BeanMap(pojo);

        String tableName = pojo.getClass().getSimpleName();

        List<Field> fields = FieldUtils.getFieldsListWithAnnotation(pojo.getClass(), Mapped.class);
        Set<String> allowedNames = fields.stream().map(f->f.getName()).collect(Collectors.toSet());

        List<String> keys = new ArrayList<>();
        List<String> vals = new ArrayList<>();
        for (Object kObj : map.keySet()) {
            String k = kObj.toString();
            if (allowedNames.contains(k)) {

                if (k.equalsIgnoreCase("class"))
                    continue;


                keys.add(k.toUpperCase());
                if (map.get(k) instanceof String) {
                    vals.add("'" + map.get(k).toString() + "'");
                } else {
                    vals.add(String.valueOf(map.get(k)));
                }
            }
        }

        if (keys.size() < 1) {
            throw new Exception("Object has not have fields mappable!");
        }
        String keysJoined = String.join(",", keys);
        String valsJoined = String.join(",", vals);
        String sql = "INSERT INTO " + tableName + " (" + keysJoined + ") values (" + valsJoined+ ")";
        return sql;

    }
}
