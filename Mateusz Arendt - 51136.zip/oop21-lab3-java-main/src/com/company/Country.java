package com.company;

import java.math.BigDecimal;

public enum Country {

    POLAND("polish", "PL", BigDecimal.valueOf(5942,-8)),
    UKRAINE("ukrainian", "UA", BigDecimal.valueOf(1556,-8)),
    FRANCE("french", "FR", BigDecimal.valueOf(18860,-8)),
    ITALY("italian", "IT", BigDecimal.valueOf(26030,-8)),

    VATICAN("latin", "VA", BigDecimal.valueOf(10,-8));

    private final String language;

    private final String code;


    private final BigDecimal GDP;

    Country(String language, String code, BigDecimal GDP) {
        this.language = language;
        this.code = code;
        this.GDP = GDP;
    }

    public BigDecimal getGDPinPLN() {
        return GDP.multiply(BigDecimal.valueOf(4.26));
    }

    @Override
    public String toString() {
        return "Country{" +
                "language='" + language + '\'' +
                ", code='" + code + '\'' +
                ", GDP=" + GDP +
                '}';
    }
}
