package com.company.runnable;

public class Fighter extends Runner { // 9b


    public Fighter(String name) {
        super(name);
    }

    @Override
    public void run() {
        super.run();
        finishHim();
    }


    public void finishHim() {
        System.out.println(toString() + " Hard to die when the Sun is shine ...");
    }


}
