package com.company.runnable;

public class Runner implements Runnable { // zadanie 9a



    private String name;

    private Finisher finisher = null;

    public Runner(String name, Finisher finisher) {
        this.name = name;
        this.finisher = finisher;
    }

    public Runner(String name) {
        this.name = name;
    }

    @Override
    public void run() {
        try {
            for (int i = 10; i > 0; i--) {
                System.out.println(String.format("%s my count is %d", this.name, i));
                Thread.currentThread().sleep(1000 + System.currentTimeMillis() % 13);
            }
            if (this.finisher != null) {
                this.finisher.finishHim();
            }
        } catch(InterruptedException e) {
            System.out.println(this.name + " is killed");
        }
    }

    @Override
    public String toString() {
        return "Runner{" +
                "name='" + name + '\'' +
                '}';
    }
}
