package com.company.runnable;

@FunctionalInterface
public interface Finisher { // task9c

    void finishHim();
}
