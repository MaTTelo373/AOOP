package com.company.runnable;

import java.util.Random;
import java.util.concurrent.Callable;

public class MyCallable implements Callable<Double> {
    public Finisher finisher = null;

    public MyCallable(Finisher finisher) {
        this.finisher = finisher;
    } //9f

    public MyCallable() {
    }

    @Override
    public Double call() throws Exception {
        Random r = new Random();
        for (int i = 10; i > 0; i--) {
            System.out.println(String.format("Count is %d",  i));
            Thread.currentThread().sleep(1000 + r.nextInt() % 17);
        }

        Double result = r.nextDouble(0d, 1d);

        if (this.finisher != null) {
           this.finisher.finishHim();
        }
        return result;
    }
}
